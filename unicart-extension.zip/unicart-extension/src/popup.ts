import { auth, signInWithGoogleExtension, logoutExtension } from "./firebaseClient";
import { onAuthStateChanged } from "firebase/auth";
import { getActiveTabUrl, parseUrl, saveItemToApi } from "./api";

const statusEl = document.getElementById("status") as HTMLElement;
const msgEl = document.getElementById("msg") as HTMLElement;

const loginBtn = document.getElementById("loginBtn") as HTMLButtonElement;
const logoutBtn = document.getElementById("logoutBtn") as HTMLButtonElement;
const saveBtn = document.getElementById("saveBtn") as HTMLButtonElement; // <-- zorg dat deze bestaat in popup.html

function setMsg(s: string) {
  msgEl.textContent = s;
}

function setLoggedInUI(emailOrLabel: string) {
  statusEl.textContent = emailOrLabel;
  loginBtn.style.display = "none";
  logoutBtn.style.display = "block";
  saveBtn.style.display = "block";
}

function setLoggedOutUI() {
  statusEl.textContent = "Not logged in";
  loginBtn.style.display = "block";
  logoutBtn.style.display = "none";
  saveBtn.style.display = "none";
}

loginBtn.onclick = async () => {
  try {
    setMsg("");
    loginBtn.disabled = true;
    await signInWithGoogleExtension();
  } catch (e: any) {
    console.error(e);
    setMsg(`Login failed: ${e?.message || String(e)}`);
  } finally {
    loginBtn.disabled = false;
  }
};

logoutBtn.onclick = async () => {
  try {
    setMsg("");
    logoutBtn.disabled = true;
    await logoutExtension();
  } catch (e: any) {
    console.error(e);
    setMsg(`Logout failed: ${e?.message || String(e)}`);
  } finally {
    logoutBtn.disabled = false;
  }
};

saveBtn.onclick = async () => {
  try {
    setMsg("");
    const user = auth.currentUser;
    if (!user) {
      setMsg("Please login first.");
      return;
    }

    saveBtn.disabled = true;
    setMsg("Saving...");

    const url = await getActiveTabUrl();
    const parsed = await parseUrl(url);

    const idToken = await user.getIdToken();
    await saveItemToApi(idToken, {
      title: parsed.title || parsed.url,
      url: parsed.url,
      shop: parsed.shop || parsed.domain,
      price: parsed.price ?? null,
      image: parsed.image || "",
      domain: parsed.domain,
      category: null,
    });

    setMsg("✅ Saved to My UniCart!");
  } catch (e: any) {
    console.error(e);
    setMsg(`❌ ${e?.message || String(e)}`);
  } finally {
    saveBtn.disabled = false;
  }
};

onAuthStateChanged(auth, (user) => {
  if (user) setLoggedInUI(user.email || "Logged in");
  else setLoggedOutUI();
});


