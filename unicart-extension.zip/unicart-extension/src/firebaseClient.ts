import { initializeApp } from "firebase/app";
import {
  getAuth,
  signInWithCredential,
  GoogleAuthProvider,
  signOut,
} from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyDb60KytW61daVI1hf2G8RwSeYyERFXGX0",
  authDomain: "unishopcart.firebaseapp.com",
  projectId: "unishopcart",
  appId: "1:75497122420:web:f5325553a8f0252574ff21",
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

// MV3 types can return GetAuthTokenResult instead of string.
// This helper normalizes it to a token string.
function extractToken(t: any): string | null {
  if (!t) return null;
  if (typeof t === "string") return t;
  if (typeof t === "object") {
    // common fields across typings
    if (typeof t.token === "string") return t.token;
    if (typeof t.accessToken === "string") return t.accessToken;
  }
  return null;
}

async function getChromeAuthToken(interactive: boolean): Promise<string> {
  return await new Promise<string>((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive }, (t) => {
      const err = chrome.runtime.lastError;
      if (err) return reject(new Error(err.message));

      const token = extractToken(t);
      if (!token) return reject(new Error("No token returned"));

      resolve(token);
    });
  });
}

export async function signInWithGoogleExtension() {
  const token = await getChromeAuthToken(true);
  const credential = GoogleAuthProvider.credential(null, token);
  return signInWithCredential(auth, credential);
}

export async function logoutExtension() {
  // optional: revoke cached token (best effort)
  try {
    const token = await getChromeAuthToken(false).catch(() => null);
    if (token) {
      chrome.identity.removeCachedAuthToken({ token }, () => {});
    }
  } catch {}

  return signOut(auth);
}
